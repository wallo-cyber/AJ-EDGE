"use client";
import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { CRMPage } from "./crm-shell";
import { simpleCrud, type SimpleRow } from "../lib/supabase/simple-crud";
import { signalPriority } from "../lib/acquisition-os/core";

const s = (v: unknown) => String(v ?? "").trim();

export function ProjectRadar() {
  const [signals, setSignals] = useState<SimpleRow[]>([]),
    [projects, setProjects] = useState<SimpleRow[]>([]),
    [companies, setCompanies] = useState<SimpleRow[]>([]);
  const [loading, setLoading] = useState(true),
    [error, setError] = useState(""),
    [notice, setNotice] = useState(""),
    // Defaults to REVIEW so rejected signals never show up without an explicit choice.
    [filter, setFilter] = useState<"ALL" | "VERIFIED" | "REVIEW" | "REJECTED">("REVIEW");
  const load = async () => {
    setLoading(true);
    try {
      const [a, b, c] = await Promise.all([
        simpleCrud.page("external_signals", 1, 1500, { order: "detected_at" }),
        simpleCrud.page("projects", 1, 1000, { order: "updated_at" }),
        simpleCrud.page("companies", 1, 1500, { order: "lead_score" }),
      ]);
      setSignals(a.rows);
      setProjects(b.rows);
      setCompanies(c.rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذر تحميل Project Radar.");
    } finally {
      setLoading(false);
    }
  };
  useEffect(() => {
    void load();
  }, []);
  const companyById = useMemo(
    () => new Map(companies.map((c) => [s(c.id), c])),
    [companies],
  );
  const linked = useMemo(
    () => new Set(projects.map((p) => s(p.source_signal_id)).filter(Boolean)),
    [projects],
  );
  const rows = useMemo(
    () =>
      signals
        .map((signal) => ({
          signal,
          score: signalPriority(signal),
          linked: linked.has(s(signal.id)),
        }))
        .filter((x) => {
          const status = s(x.signal.verification_status);
          if (filter === "ALL") return true;
          if (filter === "VERIFIED") return status === "verified";
          if (filter === "REJECTED") return status === "rejected";
          return status !== "verified" && status !== "rejected";
        })
        .sort(
          (a, b) => Number(a.linked) - Number(b.linked) || b.score - a.score,
        ),
    [signals, linked, filter],
  );
  const create = async (signal: SimpleRow) => {
    if (s(signal.verification_status) !== "verified") {
      setError("لا يمكن تحويل Signal غير معتمد إلى Project Candidate.");
      return;
    }
    if (linked.has(s(signal.id))) {
      setError("هذه الإشارة مرتبطة بمشروع بالفعل.");
      return;
    }
    try {
      const c = companyById.get(s(signal.company_id));
      const p = await simpleCrud.create("projects", {
        project_name:
          s(signal.title) || `Project Candidate — ${s(c?.company_name)}`,
        owner_company_id: s(signal.company_id) || null,
        source_signal_id: signal.id,
        project_type: s(signal.signal_type) || "UNCLASSIFIED",
        sector: s(c?.sector),
        city: s(c?.city),
        stage: "CANDIDATE",
        route_to_revenue: "UNDEFINED",
        verification_status: "needs_research",
        verification_confidence: 0,
        source_url: s(signal.source_url),
        why_now: s(signal.summary) || s(signal.title),
        last_signal_at:
          s(signal.date_found) ||
          s(signal.found_at) ||
          new Date().toISOString(),
        next_action:
          "تحقق من المشروع ثم ارسم Owner / Consultant / Main Contractor",
      });
      if (signal.company_id)
        await simpleCrud.create("project_entities", {
          project_id: p.id,
          company_id: signal.company_id,
          entity_name: s(c?.company_name),
          entity_role: "OWNER",
          status: "IDENTIFIED",
          source_url: s(signal.source_url),
          verification_status: "needs_research",
          verification_confidence: 0,
        });
      setNotice(
        "تم إنشاء Project Candidate. المشروع بقي needs_research حتى يتم التحقق البشري.",
      );
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : "تعذر إنشاء المشروع.");
    }
  };
  return (
    <CRMPage
      title="Project Radar"
      description="كل Signal يتحول إلى قرار: تجاهل، تحقق، أو Project Candidate — لا مزيد من أخبار بلا مسار تجاري."
    >
      {error && (
        <div className="rounded-xl bg-red-50 p-3 text-sm text-red-700">
          {error}
        </div>
      )}
      {notice && (
        <div className="rounded-xl bg-emerald-50 p-3 text-sm text-emerald-700">
          {notice}
        </div>
      )}
      <section className="crm-card p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <p className="text-xs font-bold text-[#8c7cff]">SIGNAL → PROJECT</p>
            <h3 className="text-xl font-bold">رادار الفرص الخارجية</h3>
          </div>
          <div className="flex gap-2">
            {(
              [
                ["ALL", "الكل"],
                ["VERIFIED", "موثقة"],
                ["REVIEW", "تحتاج مراجعة"],
                ["REJECTED", "المرفوضة"],
              ] as const
            ).map(([id, label]) => (
              <button
                key={id}
                onClick={() => setFilter(id)}
                className={filter === id ? "btn-primary" : "btn-ghost"}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
      </section>
      {loading ? (
        <div className="crm-empty">جارٍ تحليل الإشارات…</div>
      ) : (
        <div className="grid gap-3">
          {rows.map(({ signal, score, linked: isLinked }) => {
            const c = companyById.get(s(signal.company_id));
            return (
              <article key={signal.id} className="crm-card p-4">
                <div className="grid gap-4 lg:grid-cols-[1.4fr_.7fr_.8fr_auto] lg:items-center">
                  <div>
                    <div className="flex flex-wrap gap-2">
                      <span
                        className={`crm-chip ${s(signal.verification_status) === "verified" ? "status-success" : s(signal.verification_status) === "rejected" ? "status-danger" : "status-warning"}`}
                      >
                        {s(signal.verification_status)}
                      </span>
                      {isLinked && (
                        <span className="crm-chip status-neutral">
                          مرتبط بمشروع
                        </span>
                      )}
                    </div>
                    <h3 className="mt-2 text-lg font-bold">
                      {s(signal.title) || s(signal.signal_type) || "Signal"}
                    </h3>
                    <p className="mt-1 text-xs text-[#8f96a3]">
                      {s(c?.company_name) || "شركة غير مرتبطة"} ·{" "}
                      {s(c?.sector) || "قطاع غير محدد"} ·{" "}
                      {s(c?.city) || "مدينة غير محددة"}
                    </p>
                    <p className="mt-2 text-sm">
                      {s(signal.summary) || "لا يوجد ملخص محفوظ."}
                    </p>
                  </div>
                  <div>
                    <span className="text-xs text-[#8f96a3]">Radar Score</span>
                    <b className="block text-3xl">{score}</b>
                  </div>
                  <div className="text-xs">
                    <p>
                      Event Match{" "}
                      <b>{Number(signal.event_match_confidence || 0)}</b>
                    </p>
                    <p>
                      Entity Match{" "}
                      <b>{Number(signal.entity_match_confidence || 0)}</b>
                    </p>
                    <p>
                      Source Quality{" "}
                      <b>{Number(signal.source_quality_confidence || 0)}</b>
                    </p>
                  </div>
                  <div className="flex flex-wrap gap-2 lg:flex-col">
                    {s(signal.source_url) && (
                      <a
                        href={s(signal.source_url)}
                        target="_blank"
                        rel="noreferrer"
                        className="btn-ghost"
                      >
                        المصدر
                      </a>
                    )}
                    {isLinked ? (
                      <Link
                        href={`/projects/${projects.find((p) => s(p.source_signal_id) === s(signal.id))?.id}`}
                        className="btn-secondary"
                      >
                        فتح المشروع
                      </Link>
                    ) : (
                      <button
                        disabled={s(signal.verification_status) !== "verified"}
                        onClick={() => void create(signal)}
                        className="btn-primary disabled:opacity-40"
                      >
                        تحويل لمشروع
                      </button>
                    )}
                  </div>
                </div>
              </article>
            );
          })}
          {!rows.length && (
            <div className="crm-empty">لا توجد Signals مطابقة لهذا الفلتر.</div>
          )}
        </div>
      )}
    </CRMPage>
  );
}
