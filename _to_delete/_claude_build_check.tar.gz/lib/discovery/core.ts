export type DiscoveryStatus = 'جديد' | 'بحاجة تحقق' | 'مؤهل' | 'غير مناسب' | 'تمت إضافته للـ CRM';

export type DiscoveryInput = {
  companyName: string; companyType: string; sector: string; city: string;
  activity?: string; address?: string; tags?: string;
  website: string; generalPhone: string; generalEmail: string;
  contactName: string; contactPosition: string; linkedIn: string;
  contactEmail?: string; contactPhone?: string;
  discoverySource: string; sourceUrl: string; notes: string;
  projectSignal: boolean; verificationStatus?: string;
};

export const safeText = (value: unknown) => typeof value === 'string' ? value.trim() : value == null ? '' : String(value).trim();

const easternCities = ['الدمام', 'الخبر', 'الظهران', 'الجبيل', 'رأس تنورة', 'راس تنورة', 'القطيف', 'الشرقية'];

export function normalizeText(value: unknown) {
  return safeText(value).toLowerCase().replace(/[\s\-_.,،/\\()]+/g, '').replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, '');
}

export function normalizePhone(value: unknown) {
  const digits = safeText(value).replace(/\D/g, '');
  return digits.startsWith('966') ? digits.slice(3) : digits.replace(/^0/, '');
}

export function isDuplicate(a: DiscoveryInput, b: DiscoveryInput) {
  const nameA = normalizeText(a.companyName);
  const nameB = normalizeText(b.companyName);
  if (nameA && nameB && nameA === nameB) return true;
  const siteA = normalizeText(a.website);
  const siteB = normalizeText(b.website);
  if (siteA && siteB && siteA === siteB) return true;
  const phoneA = normalizePhone(a.generalPhone);
  const phoneB = normalizePhone(b.generalPhone);
  return phoneA.length >= 7 && phoneA === phoneB;
}

function domain(value: unknown) { const text=safeText(value).toLowerCase();const host=(text.includes('@')?text.split('@').pop()??'':text.replace(/^https?:\/\//,'').replace(/^www\./,'').split('/')[0]).replace(/:\d+$/,'').replace(/\.$/,'');return host; }
function coreName(value: unknown) { return normalizeText(safeText(value).replace(/شركة|مؤسسة|مصنع|مجموعة|للمقاولات|والتجارة|المحدودة|ذ\.م\.م/gi, '')); }
function similarity(a: unknown,b: unknown){const left=coreName(a),right=coreName(b);if(!left||!right)return 0;if(left===right)return 1;if(left.length<2||right.length<2)return 0;const pairs=(value:string)=>{const result:string[]=[];for(let i=0;i<value.length-1;i+=1)result.push(value.slice(i,i+2));return result};const rightPairs=pairs(right),leftPairs=pairs(left);let matches=0;for(const pair of leftPairs){const index=rightPairs.indexOf(pair);if(index>=0){matches+=1;rightPairs.splice(index,1)}}return 2*matches/(leftPairs.length+pairs(right).length);}
const freeEmailDomains=new Set(['gmail.com','hotmail.com','outlook.com','yahoo.com','icloud.com','live.com']);
export type DuplicateStatus = 'Exact Duplicate' | 'Possible Duplicate' | 'New Lead';
export function duplicateStatus(a: DiscoveryInput, b: DiscoveryInput): DuplicateStatus {
  const nameA=normalizeText(a.companyName),nameB=normalizeText(b.companyName); if(nameA&&nameA===nameB)return 'Exact Duplicate';
  const phoneA=normalizePhone(a.generalPhone),phoneB=normalizePhone(b.generalPhone);if(phoneA.length>=7&&phoneA===phoneB)return 'Exact Duplicate';
  const websiteA=domain(a.website),websiteB=domain(b.website);if(websiteA&&websiteA===websiteB)return 'Exact Duplicate';
  const emailA=safeText(a.generalEmail).toLowerCase(),emailB=safeText(b.generalEmail).toLowerCase();if(emailA&&emailA===emailB)return 'Exact Duplicate';
  const score=similarity(a.companyName,b.companyName),sameCity=normalizeText(a.city)!==''&&normalizeText(a.city)===normalizeText(b.city);const emailDomainA=domain(a.generalEmail),emailDomainB=domain(b.generalEmail);const corporateDomainMatch=emailDomainA&&emailDomainA===emailDomainB&&!freeEmailDomains.has(emailDomainA);
  if (corporateDomainMatch || score>=0.94 || (sameCity&&score>=0.86)) return 'Possible Duplicate';
  return 'New Lead';
}

export function calculateLeadScore(item: DiscoveryInput) {
  const haystack = `${safeText(item.companyType)} ${safeText(item.sector)} ${safeText(item.activity)}`.toLowerCase();
  const typeScore = /مصنع|صناع/.test(haystack) ? 20 : /مطور|عقار/.test(haystack) ? 18 : /مقاول|إنشاء/.test(haystack) ? 20 : 6;
  const fitScore = /مقاول|إنشاء|بناء|صناع|مصنع|عقار|تطوير|بنية/.test(haystack) ? 25 : 8;
  const geoScore = easternCities.some((city) => safeText(item.city).includes(city)) ? 20 : safeText(item.city) ? 8 : 0;
  const projectsScore = Boolean(item.projectSignal) || /مشروع|توسع|تنفيذ|تطوير/.test(safeText(item.notes)) ? 20 : 7;
  const contactScore = Math.min(15, (item.generalPhone ? 5 : 0) + (item.generalEmail ? 5 : 0) + (item.website ? 5 : 0));
  return Math.min(100, typeScore + fitScore + geoScore + projectsScore + contactScore);
}

export function scoreDetails(item: DiscoveryInput) {
  const reasons: string[] = []; const missing: string[] = [];
  const score = calculateLeadScore(item);
  if (/مصنع|صناع|مقاول|عقار|تطوير/.test(`${safeText(item.companyType)} ${safeText(item.sector)} ${safeText(item.activity)}`)) reasons.push('نشاط ملائم للمقاولات');
  if (easternCities.some((city) => safeText(item.city).includes(city))) reasons.push(`ضمن النطاق الجغرافي: ${safeText(item.city)}`);
  if (item.projectSignal) reasons.push('مؤشرات مشاريع أو توسع');
  if (item.contactName) reasons.push('مسؤول تواصل متوفر'); else missing.push('مسؤول تواصل');
  if (item.website) reasons.push('موقع إلكتروني متوفر'); else missing.push('الموقع الإلكتروني');
  if (!item.generalEmail && !item.contactEmail) missing.push('البريد الإلكتروني');
  if (!item.generalPhone && !item.contactPhone) missing.push('الهاتف');
  return { score, reasons, missing };
}

export function dataCompleteness(item: DiscoveryInput) {
  const values = [item.companyName,item.companyType,item.sector,item.activity,item.city,item.website,item.generalPhone,item.generalEmail,item.contactName,item.contactPosition,item.linkedIn,item.discoverySource,item.sourceUrl];
  return Math.round(values.filter((value)=>Boolean(safeText(value))).length / values.length * 100);
}

function splitCsvLine(line: string) {
  const cells: string[] = []; let current = ''; let quoted = false;
  for (let i = 0; i < line.length; i += 1) {
    const char = line[i];
    if (char === '"' && line[i + 1] === '"') { current += '"'; i += 1; }
    else if (char === '"') quoted = !quoted;
    else if (char === ',' && !quoted) { cells.push(current.trim()); current = ''; }
    else current += char;
  }
  cells.push(current.trim()); return cells;
}

export function parseDiscoveryCsv(csv: unknown): DiscoveryInput[] {
  const lines = safeText(csv).replace(/^\uFEFF/, '').split(/\r?\n/).filter((line) => line.trim());
  if (lines.length < 2) return [];
  const headers = splitCsvLine(lines[0]).map(normalizeText);
  const aliases: Record<keyof Omit<DiscoveryInput, 'projectSignal'>, string[]> = {
    companyName: ['companyname', 'name', 'اسمالشركة', 'الاسم'], companyType: ['companytype', 'type', 'نوعالشركة', 'النوع', 'الفئة'],
    sector: ['sector', 'القطاع', 'النشاط'], city: ['city', 'المدينة'], website: ['website', 'الموقع', 'الموقعالإلكتروني'],
    generalPhone: ['phone', 'generalphone', 'الهاتف'], generalEmail: ['email', 'generalemail', 'البريد', 'البريدالإلكتروني'],
    contactName: ['contactname', 'اسممسؤولالتواصل', 'مسؤولالتواصل'], contactPosition: ['contactposition','contacttitle', 'منصبمسؤولالتواصل', 'المنصب'],
    linkedIn: ['linkedin', 'لينكدإن', 'لينكدان'],
    activity: ['activity','النشاط'], address: ['address','العنوان'], tags: ['tags','الوسوم'],
    contactEmail: ['contactemail','بريدالمسؤول'], contactPhone: ['contactphone','هاتفالمسؤول'],
    discoverySource: ['source','sourcename', 'discoverysource', 'المصدر', 'مصدرالبيانات'], sourceUrl: ['sourceurl', 'رابطالمصدر'],
    notes: ['notes', 'ملاحظات'], verificationStatus: ['verificationstatus', 'حالةالتحقق'],
  };
  const value = (cells: string[], key: keyof typeof aliases) => {
    const index = headers.findIndex((header) => aliases[key].includes(header)); return index >= 0 ? cells[index] ?? '' : '';
  };
  return lines.slice(1).map(splitCsvLine).map((cells) => ({
    companyName: value(cells, 'companyName'), companyType: value(cells, 'companyType'), sector: value(cells, 'sector'),
    city: value(cells, 'city'), website: value(cells, 'website'), generalPhone: value(cells, 'generalPhone'),
    generalEmail: value(cells, 'generalEmail'), discoverySource: value(cells, 'discoverySource') || 'CSV',
    contactName: value(cells, 'contactName'), contactPosition: value(cells, 'contactPosition'), linkedIn: value(cells, 'linkedIn'),
    activity: value(cells, 'activity'), address: value(cells, 'address'), tags: value(cells, 'tags'), contactEmail: value(cells, 'contactEmail'), contactPhone: value(cells, 'contactPhone'),
    sourceUrl: value(cells, 'sourceUrl'), notes: value(cells, 'notes'), projectSignal: false,
    verificationStatus: value(cells, 'verificationStatus') || 'بحاجة تحقق',
  }));
}

export type ImportReport = { total: number; accepted: DiscoveryInput[]; duplicates: number; needsReview: number; rejected: number };
export type RejectedImportRow = { rowNumber: number; companyName: string; reasons: string[] };
export function validateImportRows(items: DiscoveryInput[]) {
  const valid: DiscoveryInput[] = []; const rejections: RejectedImportRow[] = [];
  items.forEach((item,index)=>{const reasons:string[]=[];if(!safeText(item.companyName))reasons.push('اسم الشركة مفقود');if(!safeText(item.companyType))reasons.push('فئة الشركة مفقودة');if(!safeText(item.city))reasons.push('المدينة مفقودة');if(reasons.length)rejections.push({rowNumber:index+2,companyName:safeText(item.companyName)||'—',reasons});else valid.push(item);});
  return { valid, rejections };
}
export function prepareImport(items: DiscoveryInput[], existing: DiscoveryInput[]): ImportReport {
  const accepted: DiscoveryInput[] = []; let duplicates = 0; let rejected = 0; let needsReview = 0;
  for (const item of items) {
    if (!safeText(item.companyName) || !safeText(item.companyType) || !safeText(item.city)) { rejected += 1; continue; }
    if ([...existing, ...accepted].some((candidate) => duplicateStatus(item, candidate) === 'Exact Duplicate')) { duplicates += 1; continue; }
    if (!item.website && !item.generalPhone && !item.generalEmail) needsReview += 1;
    accepted.push(item);
  }
  return { total: items.length, accepted, duplicates, needsReview, rejected };
}

export const discoveryCsvTemplate = '\uFEFFcompany_name,company_type,sector,activity,city,website,general_phone,general_email,contact_name,contact_title,contact_email,contact_phone,linkedin,source_name,source_url,notes\r\n';
